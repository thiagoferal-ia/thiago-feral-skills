// Sky Hop: tap to hop between clouds.
const allowed = ['skyhop.example.com', 'localhost'];
if (!allowed.includes(location.hostname)) { document.body.innerHTML = 'This game is only available at skyhop.example.com'; throw new Error('sitelock'); }
const c = document.getElementById('c'), x = c.getContext('2d');
let W, H, y = 0, vy = 0, score = 0, best = +localStorage.getItem('skyhop-best') || 0;
const isMobile = 'ontouchstart' in window;
function resize() { W = c.width = innerWidth; H = c.height = innerHeight; }
addEventListener('resize', resize); resize();
document.getElementById('fs').onclick = () => document.documentElement.requestFullscreen();
document.getElementById('login').onclick = () => firebase.auth().signInWithPopup(new firebase.auth.GoogleAuthProvider());
function gameOver() {
  localStorage.setItem('skyhop-best', Math.max(best, score));
  if (window.gdsdk) gdsdk.showAd();
  if (confirm('Game over! Play more games?')) window.open('https://www.example-games.com/more', '_blank');
}
function loop() { vy += 0.5; y += vy; if (y > H) { gameOver(); y = 0; vy = 0; score = 0; } x.fillStyle = '#7ec8ff'; x.fillRect(0, 0, W, H); x.fillStyle = '#fff'; x.beginPath(); x.arc(W / 2, y, 20, 0, 7); x.fill(); requestAnimationFrame(loop); }
addEventListener(isMobile ? 'touchstart' : 'mousedown', () => { vy = -10; score++; });
loop();
